import SwiftUI

enum BiographySection: String, CaseIterable, Identifiable {
    case profile
    case papers
    case theories
    case timeline
    case map

    var id: String { rawValue }

    var title: LocalizedStringResource {
        switch self {
        case .profile: "人物資料"
        case .papers: "原始論文"
        case .theories: "理論實驗室"
        case .timeline: "生平時間線"
        case .map: "世界座標"
        }
    }

    var icon: String {
        switch self {
        case .profile: "person.text.rectangle"
        case .papers: "doc.text"
        case .theories: "atom"
        case .timeline: "timeline.selection"
        case .map: "map"
        }
    }
}

struct ContentView: View {
    @Environment(\.colorScheme) private var colorScheme
    @AppStorage("appAppearance") private var appearance = AppAppearance.system
    @State private var selectedTheory: TheoryDetail?
    @State private var selectedPaper: ScientificPaper?

    var body: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(spacing: 0) {
                    ImmersiveHeroSection()
                    CuratedBiographyContent(onSelectTheory: { theory in
                        selectedTheory = theory
                    }, onSelectPaper: { paper in
                        selectedPaper = paper
                    })
                }
            }
            .background(colorScheme == .dark ? Color.einsteinNavy : Color(red: 0.96, green: 0.95, blue: 0.92))
            .ignoresSafeArea(edges: .top)
            .overlay(alignment: .top) {
                HStack {
                    SectionNavigationMenu { section in
                        withAnimation(.smooth) {
                            proxy.scrollTo(section, anchor: .top)
                        }
                    }

                    Spacer()

                    AppearanceMenu(
                        selection: $appearance,
                        effectiveColorScheme: colorScheme
                    )
                }
                .padding(.top, 54)
                .padding(.horizontal, 18)
            }
        }
        .preferredColorScheme(appearance.colorScheme)
        .sheet(item: $selectedTheory) { theory in
            TheoryDetailScreen(theory: theory)
        }
        .sheet(item: $selectedPaper) { paper in
            ScientificPaperDetailScreen(paper: paper)
        }
    }
}

struct SectionNavigationMenu: View {
    let onSelect: (BiographySection) -> Void
    @State private var isShowingSections = false

    var body: some View {
        Button {
            isShowingSections = true
        } label: {
            Image(systemName: "list.bullet")
                .font(.einsteinHeadline)
                .symbolEffect(.bounce, value: isShowingSections)
                .foregroundStyle(.white)
                .frame(width: 44, height: 44)
                .background(.ultraThinMaterial, in: Circle())
                .overlay {
                    Circle()
                        .stroke(.white.opacity(0.24), lineWidth: 1)
                        .allowsHitTesting(false)
                }
        }
        .buttonStyle(.plain)
        .popover(isPresented: $isShowingSections, arrowEdge: .top) {
            VStack(spacing: 4) {
                Text("章節導覽")
                    .font(.einsteinCaption.bold())
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 10)
                    .padding(.bottom, 4)

                ForEach(BiographySection.allCases) { section in
                    Button {
                        isShowingSections = false
                        onSelect(section)
                    } label: {
                        HStack(spacing: 12) {
                            Image(systemName: section.icon)
                                .frame(width: 22)
                            Text(section.title)
                                .font(.einsteinBody)
                            Spacer()
                        }
                        .foregroundStyle(.primary)
                        .padding(.horizontal, 10)
                        .frame(height: 44)
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(8)
            .frame(width: 240)
            .presentationCompactAdaptation(.popover)
        }
        .accessibilityLabel("章節導覽")
        .accessibilityHint("快速前往人物資料、論文、理論、時間線或地圖")
    }
}

struct ZoomablePortrait: View {
    @State private var scale: CGFloat = 1
    @State private var storedScale: CGFloat = 1
    @State private var offset: CGSize = .zero
    @State private var storedOffset: CGSize = .zero

    private let minimumScale: CGFloat = 1
    private let maximumScale: CGFloat = 4

    var body: some View {
        Image("EinsteinPortrait")
            .resizable()
            .scaledToFit()
            .frame(maxWidth: .infinity)
            .frame(height: 590, alignment: .top)
            .background(Color.einsteinNavy)
            .scaleEffect(scale)
            .offset(offset)
            .simultaneousGesture(magnifyGesture)
            .simultaneousGesture(dragGesture)
            .onTapGesture(count: 2) {
                withAnimation(.smooth(duration: 0.35)) {
                    if scale > minimumScale {
                        resetTransform()
                    } else {
                        scale = 2
                        storedScale = 2
                    }
                }
            }
            .accessibilityLabel("阿爾伯特・愛因斯坦人物插畫")
            .accessibilityHint("雙擊放大或還原，也可使用雙指縮放與拖曳")
            .accessibilityAction(named: "放大圖片") {
                withAnimation(.smooth) {
                    scale = min(maximumScale, scale + 1)
                    storedScale = scale
                }
            }
            .accessibilityAction(named: "還原圖片") {
                withAnimation(.smooth) {
                    resetTransform()
                }
            }
    }

    private var magnifyGesture: some Gesture {
        MagnifyGesture()
            .onChanged { value in
                scale = min(maximumScale, max(minimumScale, storedScale * value.magnification))
            }
            .onEnded { _ in
                storedScale = scale
                if scale <= minimumScale {
                    resetTransform()
                }
            }
    }

    private var dragGesture: some Gesture {
        DragGesture(minimumDistance: 8)
            .onChanged { value in
                guard scale > minimumScale else { return }
                offset = CGSize(
                    width: storedOffset.width + value.translation.width,
                    height: storedOffset.height + value.translation.height
                )
            }
            .onEnded { _ in
                guard scale > minimumScale else { return }
                storedOffset = offset
            }
    }

    private func resetTransform() {
        scale = minimumScale
        storedScale = minimumScale
        offset = .zero
        storedOffset = .zero
    }
}

struct ImmersiveHeroSection: View {
    var body: some View {
        ZStack(alignment: .bottomLeading) {
            ZoomablePortrait()

            LinearGradient(
                stops: [
                    .init(color: Color.einsteinNavy.opacity(0.08), location: 0),
                    .init(color: Color.einsteinNavy.opacity(0.12), location: 0.45),
                    .init(color: Color.einsteinNavy.opacity(0.96), location: 0.88),
                    .init(color: Color.einsteinNavy, location: 1)
                ],
                startPoint: .top,
                endPoint: .bottom
            )
            .allowsHitTesting(false)

            VStack(alignment: .leading, spacing: 18) {
                HStack(spacing: 8) {
                    Circle().fill(Color.einsteinGold).frame(width: 7, height: 7)
                    Text("FIELD NOTES · ISSUE 01")
                        .font(.einsteinCaption2.bold())
                        .tracking(2)
                }
                .foregroundStyle(Color.einsteinGold)

                Text("ALBERT\nEINSTEIN")
                    .font(.custom(EinsteinTypography.displayFontName, size: 58, relativeTo: .largeTitle))
                    .fontWeight(.semibold)
                    .minimumScaleFactor(0.7)
                    .foregroundStyle(.white)
                    .lineSpacing(-8)

                HStack(spacing: 10) {
                    Text("1879—1955")
                    Text("•")
                    Text("SPACE · TIME · LIGHT")
                }
                .font(.einsteinCaption.bold())
                .tracking(1)
                .foregroundStyle(.white.opacity(0.68))

                LaTeXText(
                    latex: #"E = mc^{2}"#,
                    pointSize: 24,
                    weight: .bold,
                    color: UIColor(Color.einsteinGold)
                )
                    .padding(.horizontal, 16)
                    .padding(.vertical, 10)
                    .background(.ultraThinMaterial, in: Capsule())
            }
            .padding(.horizontal, 24)
            .padding(.bottom, 42)
            .allowsHitTesting(false)
        }
        .frame(height: 590)
        .clipShape(SpacetimePortraitShape())
        .accessibilityElement(children: .combine)
    }
}

struct CuratedBiographyContent: View {
    let onSelectTheory: (TheoryDetail) -> Void
    let onSelectPaper: (ScientificPaper) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 64) {
            EditorialIntroSection()
            BiographyDossierSection(fields: EinsteinContent.biography)
                .id(BiographySection.profile)
            ScientificPapersSection(
                papers: EinsteinPaperContent.papers,
                onSelectPaper: onSelectPaper
            )
            .id(BiographySection.papers)
            TheoryGallerySection(
                theories: EinsteinTheoryContent.theories,
                onSelectTheory: onSelectTheory
            )
            .id(BiographySection.theories)
            VerticalTimelineSection(events: EinsteinContent.timeline)
                .id(BiographySection.timeline)
            EinsteinMapSection()
                .id(BiographySection.map)
            ExhibitionFinale()
        }
        .frame(maxWidth: 820)
        .padding(.horizontal, 20)
        .padding(.top, 24)
        .padding(.bottom, 40)
        .frame(maxWidth: .infinity)
    }
}

struct BiographyDossierSection: View {
    let fields: [BiographyField]
    private let columns = [GridItem(.adaptive(minimum: 220), spacing: 12)]

    var body: some View {
        VStack(alignment: .leading, spacing: 22) {
            SectionHeader(
                eyebrow: "Identity file",
                title: "人物基本資料",
                subtitle: "從身分、教育與研究領域，到任職機構與個人興趣的完整人物檔案。"
            )

            LazyVGrid(columns: columns, alignment: .leading, spacing: 12) {
                ForEach(fields) { field in
                    BiographyFieldCard(field: field)
                }
            }
        }
    }
}

struct BiographyFieldCard: View {
    let field: BiographyField

    var body: some View {
        HStack(alignment: .top, spacing: 13) {
            Image(systemName: field.icon)
                .font(.einsteinSubheadline)
                .foregroundStyle(Color.einsteinGold)
                .frame(width: 36, height: 36)
                .background(Color.einsteinGold.opacity(0.12), in: Circle())

            VStack(alignment: .leading, spacing: 5) {
                Text(field.label.uppercased())
                    .font(.einsteinCaption2.bold())
                    .tracking(1)
                    .foregroundStyle(.secondary)

                Text(field.value)
                    .font(.einsteinSubheadline.weight(.semibold))
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .frame(maxWidth: .infinity, minHeight: 94, alignment: .topLeading)
        .padding(15)
        .background(Color.einsteinCard, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .accessibilityElement(children: .combine)
    }
}

struct EditorialIntroSection: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 24) {
            SectionHeader(
                eyebrow: "The mind that reframed reality",
                title: "不是解答世界，\n而是重寫問題",
                subtitle: "從光的粒子性到彎曲時空，愛因斯坦以少數原理建立可被實驗推翻、也能被精密驗證的理論。"
            )

            Text("他在學術體制之外保持罕見的思想自由：先辨認理論矛盾，再尋找不依賴觀察者的結構，最後提出能交由實驗回答的預言。")
                .font(.einsteinBody)
                .foregroundStyle(.secondary)
                .lineSpacing(7)
        }
    }
}

struct TheoryGallerySection: View {
    let theories: [TheoryDetail]
    let onSelectTheory: (TheoryDetail) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 22) {
            SectionHeader(
                eyebrow: "Seven ideas · One universe",
                title: "理論實驗室",
                subtitle: "先看見核心命題，再點開完整的假設、公式推導、符號定義與物理結論。"
            )

            ScrollView(.horizontal) {
                HStack(alignment: .top, spacing: 14) {
                    ForEach(theories) { theory in
                        Button {
                            onSelectTheory(theory)
                        } label: {
                            TheoryPreviewCard(theory: theory)
                        }
                        .buttonStyle(.einsteinCard)
                        .accessibilityHint("開啟完整理論推導")
                    }
                }
                .padding(.vertical, 2)
            }
            .scrollIndicators(.hidden)
        }
    }
}

struct TheoryPreviewCard: View {
    let theory: TheoryDetail

    var body: some View {
        ZStack(alignment: .topTrailing) {
            Text(theory.number)
                .font(.custom(EinsteinTypography.displayFontName, size: 82))
                .foregroundStyle(theory.accent.opacity(0.10))
                .offset(x: 6, y: -18)

            VStack(alignment: .leading, spacing: 14) {
                Image(systemName: theory.icon)
                    .font(.einsteinTitle2)
                    .foregroundStyle(theory.accent)
                    .frame(width: 46, height: 46)
                    .background(theory.accent.opacity(0.14), in: Circle())

                Spacer(minLength: 8)

                Text(theory.title)
                    .font(.einsteinTitle3.bold())
                    .foregroundStyle(.primary)

                Text(theory.subtitle)
                    .font(.einsteinCaption)
                    .foregroundStyle(.secondary)
                    .lineLimit(3)
                    .fixedSize(horizontal: false, vertical: true)

                HStack {
                    Text("完整推導")
                    Spacer()
                    Image(systemName: "arrow.up.right")
                }
                .font(.einsteinCaption.bold())
                .foregroundStyle(theory.accent)
            }
            .padding(18)
        }
        .frame(width: 252, height: 270, alignment: .topLeading)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 26, style: .continuous)
                .stroke(theory.accent.opacity(0.25), lineWidth: 1)
        }
        .clipShape(RoundedRectangle(cornerRadius: 26, style: .continuous))
        .contentShape(RoundedRectangle(cornerRadius: 26, style: .continuous))
        .accessibilityElement(children: .combine)
    }
}

struct VerticalTimelineSection: View {
    let events: [TimelineEvent]

    var body: some View {
        VStack(alignment: .leading, spacing: 22) {
            SectionHeader(
                eyebrow: "Worldline · 1879—1955",
                title: "一條穿越現代史的世界線",
                subtitle: "從童年好奇、求學與奇蹟年，到流亡、公共責任與晚年研究。"
            )

            LazyVStack(alignment: .leading, spacing: 0) {
                ForEach(events.enumerated(), id: \.element.id) { index, event in
                    VerticalTimelineRow(
                        event: event,
                        isLast: index == events.count - 1
                    )
                }
            }
            .padding(.horizontal, 4)
        }
    }
}

struct VerticalTimelineRow: View {
    let event: TimelineEvent
    let isLast: Bool

    var body: some View {
        HStack(alignment: .top, spacing: 18) {
            VStack(spacing: 0) {
                ZStack {
                    Circle()
                        .fill(Color.einsteinGold.opacity(0.18))
                        .frame(width: 28, height: 28)
                    Circle()
                        .fill(Color.einsteinGold)
                        .frame(width: 10, height: 10)
                }

                if !isLast {
                    Rectangle()
                        .fill(
                            LinearGradient(
                                colors: [Color.einsteinGold.opacity(0.55), Color.einsteinGold.opacity(0.12)],
                                startPoint: .top,
                                endPoint: .bottom
                            )
                        )
                        .frame(width: 2)
                        .frame(maxHeight: .infinity)
                }
            }

            VStack(alignment: .leading, spacing: 7) {
                Text(event.year)
                    .font(.einsteinCaption.bold().monospacedDigit())
                    .foregroundStyle(Color.einsteinGold)

                Text(event.title)
                    .font(.einsteinHeadline)

                Text(event.description)
                    .font(.einsteinSubheadline)
                    .foregroundStyle(.secondary)
                    .lineSpacing(4)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.bottom, isLast ? 0 : 30)
        }
        .accessibilityElement(children: .combine)
    }
}

struct ExhibitionFinale: View {
    var body: some View {
        ZStack(alignment: .bottomLeading) {
            RoundedRectangle(cornerRadius: 32, style: .continuous)
                .fill(
                    LinearGradient(
                        colors: [Color.einsteinNavy, Color(red: 0.08, green: 0.16, blue: 0.24)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )

            Image(systemName: "atom")
                .font(.system(size: 230, weight: .ultraLight))
                .foregroundStyle(Color.einsteinGold.opacity(0.11))
                .offset(x: 180, y: 68)

            VStack(alignment: .leading, spacing: 14) {
                Text("THE UNIVERSE IS STILL ASKING")
                    .font(.einsteinCaption.bold())
                    .tracking(2)
                    .foregroundStyle(Color.einsteinGold)

                Text("他留下的，\n不是一座完成的宇宙。")
                    .font(.einsteinTitle.bold())
                    .foregroundStyle(.white)

                Text("衛星導航、量子感測、黑洞影像與重力波天文學，仍在檢驗他開啟的框架。真正延續至今的遺產，是讓理論接受世界的回答。")
                    .font(.einsteinBody)
                    .foregroundStyle(.white.opacity(0.72))
                    .lineSpacing(5)
                    .fixedSize(horizontal: false, vertical: true)

                Text("ORIGINAL EXHIBITION · SWIFTUI")
                    .font(.einsteinCaption2.bold())
                    .tracking(1.4)
                    .foregroundStyle(.white.opacity(0.42))
                    .padding(.top, 8)
            }
            .padding(26)
        }
        .clipShape(RoundedRectangle(cornerRadius: 32, style: .continuous))
        .accessibilityElement(children: .combine)
    }
}

#Preview("Light") {
    ContentView()
        .preferredColorScheme(.light)
}

#Preview("Dark") {
    ContentView()
        .preferredColorScheme(.dark)
}
